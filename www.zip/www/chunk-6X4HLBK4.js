import{a}from"./chunk-7KGURMOZ.js";import"./chunk-S5EYVFES.js";export{a as startFocusVisible};
