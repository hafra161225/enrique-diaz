import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-S5EYVFES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
