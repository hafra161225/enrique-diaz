import{a as e}from"./chunk-FYRFPX4H.js";var t=e("Preferences",{web:()=>import("./chunk-BVAKBIXC.js").then(r=>new r.PreferencesWeb)});export{t as a};
